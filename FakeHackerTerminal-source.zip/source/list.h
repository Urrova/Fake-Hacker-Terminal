#ifndef LIST_H_INCLUDED
#define LIST_H_INCLUDED

void show_list(){

cout << "connect: connect to FBI servers" << endl << "download: download a part of top secret FBI file" << "open-secret-file: open the fragment of FBI secret file" << endl << endl << "disconnect: disconnect to the FBI servers" << endl <<"hack-google: Emmm... this hack google?" << endl << "make-annoying-virus: make an annoying virus" << endl << "info: gives info of this terminal" << endl << "exit: closes this terminal"<< endl << "list: show a list of commands" << endl;

}

void info(){
cout << "This is a fake hacker terminal. This don\'t hack nothing, is only a console whit fake hacker tools...\nMade by @URROVA (Ulises Z.)\nI wait what you enjoyed this fake terminal :)" << endl;
}
#endif // LIST_H_INCLUDED
