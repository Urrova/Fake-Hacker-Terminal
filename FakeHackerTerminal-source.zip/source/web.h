#ifndef WEB_H_INCLUDED
#define WEB_H_INCLUDED

void hack_google(){
    cout << "Connecting to www.google.com [172.217.30.142]... ";
    Sleep(500);
    cout << "Done!\nBreaking password... ";
    Sleep(2500);
    cout << "Done! \nHacking google.com ...";
    Sleep(1000);
    cout << "Done!\nsee the disaster for yourself :)";
    system("start http://arrovaut.000webhostapp.com/hacked_google/google.html");
}

#endif // WEB_H_INCLUDED
